Lore Forever translation kit
====================================

Thank you for helping Lore Forever speak your language!

WHAT TO EDIT
Every file here (except kit.json and the reference folder) is a list of strings like this:

  {
    "id": "npc:hogger/s",
    "en": "Hogger is the vicious chieftain of the Riverpaw gnolls ...",
    "text": ""
  }

Change only "text". Leave "id" and "en" exactly as they are: they tell us which English you translated, so your
work still lands in the right place after the English is updated.

  - An empty "text" means "not translated yet": the add-on shows the English there.
  - Some strings already have text. It's a draft: fix whatever reads wrong, and say so when you send it.
  - Keep codes like %s, %d and |cff00ff00 ... |r where the English has them, in the same order.
  - Keywords ("kw") and search phrases ("al") are lists: separate the items with " | ".
  - Names of places, people and quests should match what your game client calls them. The reference folder lists
    the names we already know.
  - Sections and answers marked as spoilers in the add-on are hidden until the player opts in, so translate them too.

WHERE TO START
ui.json first (the add-on's buttons and messages), then lore/zones_*.json and lore/topics_*.json. You don't have to
finish anything: every string you translate is used.

HOW TO EDIT
Use an editor that understands JSON, such as VS Code or Notepad++. Keep the quotes and commas; inside "text", write
a quote as \" and a line break as \n. Save as UTF-8.

HOW TO SEND IT
Put the files you changed (or the whole folder) in a shared Google Drive, Dropbox or OneDrive folder and send us the
link at https://loreforeverwow.com/translate/submit . Found a single wrong translation in game? Report it at
https://loreforeverwow.com/translate#report .

Your translations are shared under CC BY-SA 4.0, like the lore text they translate. Questions: ask on our Discord,
https://loreforeverwow.com/discord?src=translate
